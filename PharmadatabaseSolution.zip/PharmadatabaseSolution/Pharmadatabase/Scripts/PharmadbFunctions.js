﻿function clearText() {
    document.getElementById("AccessStartDate").value = "";
    document.getElementById("AccessEndDate").value = "";
}
function generatePassword() {
    if (document.getElementById("Password").value != "") {
        alert("Password already present.");
    }
    else {

        var text = "";
        var possible = "ABCDEFG@HIJKLMNOPQRSTU@VWXYZabcd_efghijklmno@pqrstuvw_xyz0123456789";

        for (var i = 0; i < 8; i++) {
            text += possible.charAt(Math.floor(Math.random() * possible.length));
        }
        document.getElementById("Password").value = text;
    }
}

function enableDisable() {
    var accessId = document.getElementById('AccessTypeID').value;
    if (accessId == 388) {
        document.getElementById('Year').disabled = true;
        document.getElementById('Month').disabled = true;
        document.getElementById('Day').disabled = false;
    }
    if (accessId == 389 || accessId == 390) {
        document.getElementById('Day').disabled = true;
        document.getElementById('Year').disabled = false;
        document.getElementById('Month').disabled = false;
    }
}
function genEndDate() {
    var finalDate = null;
    var monthNames = ["Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"];
    var startDate = new Date(document.getElementById("AccessStartDate").value);

    if (document.getElementById('AccessTypeID').value == 388) {
        if (document.getElementById('Day').value == 0) {
            alert("Please select value for days.");
            document.getElementById("AccessStartDate").value = "";
            document.getElementById("AccessStartEnd").value = "";
        }
        else {

            var daysToAdd = parseInt(document.getElementById('Day').value);
            finalDate = new Date(startDate.setDate(startDate.getDate() + daysToAdd));
        }

    }
    else {

        if (document.getElementById('Month').value == 0 && document.getElementById('Year').value == 0) {
            alert("Please select value for Months or Year.");
            document.getElementById("AccessStartDate").value = "";
            document.getElementById("AccessStartEnd").value = "";
        }
        else {
            var addMonths = parseInt(document.getElementById('Month').value);
            var addYears = parseInt(document.getElementById('Year').value)

            var temDate = new Date(new Date(startDate).setMonth(startDate.getMonth() + addMonths));
            finalDate = new Date(new Date(temDate).setYear(temDate.getFullYear() + addYears));
        }
    }

    var day = finalDate.getDate();
    var monthIndex = finalDate.getMonth();
    var year = finalDate.getFullYear();
    document.getElementById("AccessEndDate").value = day + '/' + monthNames[monthIndex] + '/' + year;
}
